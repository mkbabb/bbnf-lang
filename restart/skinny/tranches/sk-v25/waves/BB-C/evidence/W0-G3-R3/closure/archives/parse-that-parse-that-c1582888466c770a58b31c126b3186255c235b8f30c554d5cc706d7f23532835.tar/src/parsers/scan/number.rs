// Number scanning core — mantissa accumulation + config.
//
// Pure digit/mantissa scanning. f64 conversion lives in `number_f64.rs`.
// SIMD digit accumulation (16 bytes at a time) lives in `number_simd.rs`.

use super::number_simd;
use crate::state::PaddedView;

// ── Number scanning core ──────────────────────────────────────────

/// Accumulated mantissa + metadata from scanning a decimal number string.
pub struct NumberParts {
    pub mantissa: u64,
    pub exponent: i32,
    pub negative: bool,
    pub n_digits: u32,
    /// True when no fractional or exponent part was present.
    pub is_integer: bool,
}

/// Configuration controlling which number syntax is accepted.
pub struct NumberConfig {
    /// Accept `+` as a leading sign.
    pub allow_plus_sign: bool,
    /// Accept `.5` (no digits before the decimal point).
    pub allow_leading_dot: bool,
    /// Reject `007`-style leading zeros (RFC 8259 rule).
    pub reject_leading_zero: bool,
}

pub const GENERIC_NUMBER_CONFIG: NumberConfig = NumberConfig {
    allow_plus_sign: true,
    allow_leading_dot: true,
    reject_leading_zero: false,
};

pub const STRICT_NUMBER_CONFIG: NumberConfig = NumberConfig {
    allow_plus_sign: false,
    allow_leading_dot: false,
    reject_leading_zero: true,
};

/// Convert 8 ASCII digit bytes to a u64 in ~3 multiply-shift operations.
/// Ported from simdjson's `parse_eight_digits_unrolled`.
/// Caller must guarantee that `s` contains at least 8 ASCII digit bytes.
#[inline(always)]
pub fn parse_eight_digits(s: &[u8]) -> u64 {
    debug_assert!(s.len() >= 8);
    let mut val = u64::from_le_bytes(s[..8].try_into().unwrap());
    val = val.wrapping_sub(0x3030_3030_3030_3030); // subtract '0'
    // Fold pairs: each byte pair → 2-digit value in alternating bytes
    val = (val & 0x0F0F_0F0F_0F0F_0F0F).wrapping_mul(0x0A01) >> 8;
    // Fold quads: each 2-byte pair → 4-digit value
    val = (val & 0x00FF_00FF_00FF_00FF).wrapping_mul(0x0064_0001) >> 16;
    // Fold octets: combine into single value
    (val & 0x0000_FFFF_0000_FFFF).wrapping_mul(0x0000_2710_0000_0001) >> 32
}

/// Tranche Y.8 — SWAR digit validation over 8 bytes.
///
/// Replaces `chunk.iter().all(|b| b.is_ascii_digit())` (8 loads + 8
/// branches, O(8) instructions best case) with two parallel byte-class
/// compares executed as one u64 arithmetic operation each.
///
/// The test:
/// - `u - 0x3030_3030_3030_3030` has the high bit of any byte set
///   iff that byte was `< 0x30` (wrap-around).
/// - `u + 0x4646_4646_4646_4646` has the high bit of any byte set iff
///   that byte was `>= 0x3A` (the additive complement of `0x7F - 0x39`).
///
/// If both masks are zero, every byte is in `[0x30, 0x39]` (ASCII digit).
/// Compiles to ~4 instructions: one load, two `add`s, one `test`/`or`.
///
/// On `json_canada`, the scanner hot path is ~30% of self-time per the
/// post-W profile. Half of that was the unvectorizable
/// `chunk.iter().all(...)` — this SWAR check collapses it into
/// constant-time operations that LLVM can schedule alongside the
/// `parse_eight_digits` mantissa fold.
#[inline(always)]
fn all_eight_are_ascii_digits(chunk: &[u8]) -> bool {
    debug_assert!(chunk.len() >= 8);
    let u = u64::from_le_bytes(chunk[..8].try_into().unwrap());
    let lt_zero = u.wrapping_sub(0x3030_3030_3030_3030) & 0x8080_8080_8080_8080;
    let gt_nine = u.wrapping_add(0x4646_4646_4646_4646) & 0x8080_8080_8080_8080;
    (lt_zero | gt_nine) == 0
}

/// Core number scanner: accumulates mantissa with 8-digit chunking.
///
/// Scans a number from `view.bytes()[start..]` according to `cfg`,
/// accumulating the mantissa and tracking the decimal exponent in a
/// single pass. Returns `(parts, end_offset)` or `None` if no valid
/// number was found.
///
/// The [`PaddedView`] witness lets the inner SIMD digit scan load a
/// full 16-byte window at any offset `<= view.len()` without a
/// per-chunk tail guard; the NUL-padded region classifies as
/// non-digit, so every digit-walking loop terminates naturally at the
/// public input boundary. `view.len()` bounds every forward scan so
/// padded positions never leak as returned offsets.
#[inline(always)]
pub fn scan_number_mantissa(
    view: PaddedView<'_>,
    start: usize,
    cfg: &NumberConfig,
) -> Option<(NumberParts, usize)> {
    let bytes = view.bytes();
    let len = view.len();
    let mut i = start;

    if i >= len {
        return None;
    }

    // ── Sign ──────────────────────────────────────────────────
    let mut neg = false;
    let b = unsafe { *bytes.get_unchecked(i) };
    if b == b'-' {
        neg = true;
        i += 1;
        if i >= len {
            return None;
        }
    } else if b == b'+' {
        if !cfg.allow_plus_sign {
            return None;
        }
        i += 1;
        if i >= len {
            return None;
        }
    }

    // ── Integer digits — accumulate mantissa ──────────────────
    let digit_start = i;
    let mut mantissa: u64 = 0;

    // 8-digit SWAR classification is the universal first step: ~85%
    // of real-world numbers have integer runs of 1-4 digits where a
    // 16-byte NEON stripe's classification cost (byte-subtract,
    // compare, horizontal bitmask pack) outweighs the per-run savings.
    // One 8-byte `all_eight_are_ascii_digits` probe serves double
    // duty: it captures the short-run fast case AND acts as the
    // admission test for escalating to 16-byte SIMD.
    //
    // If the first 8-byte probe passes we commit that batch, then
    // pivot to `scan_digits_simd` for the tail — only numeric-dense
    // inputs (canada.json, scientific literals, large IDs) reach the
    // vector path, and they reach it exactly once per number instead
    // of paying the classification cost up front.
    //
    // Padded-view invariant: every 8-byte read at `i <= len` is
    // in-bounds on the backing buffer; `all_eight_are_ascii_digits`
    // rejects NUL so the loop terminates at the public-input boundary
    // naturally.
    if i < len && unsafe { *bytes.get_unchecked(i) }.is_ascii_digit() {
        let chunk = unsafe { bytes.get_unchecked(i..i + 8) };
        if all_eight_are_ascii_digits(chunk) {
            mantissa = mantissa
                .wrapping_mul(100_000_000)
                .wrapping_add(parse_eight_digits(chunk));
            i += 8;

            // Pivot to 16-byte SIMD for the tail. Every stripe that
            // returns 16 extends the run by 16 digits; a stripe
            // returning < 16 signals the end of the integer part
            // (or a budget break).
            while let Some(result) = number_simd::scan_digits_simd(view, i) {
                let c = result.count as usize;
                let new_total = (i - digit_start) + c;
                if new_total <= 19 {
                    mantissa = mantissa
                        .wrapping_mul(number_simd::POW10[c])
                        .wrapping_add(result.value);
                    i += c;
                    if c < 16 {
                        break;
                    }
                } else {
                    // A full 16-digit stripe would push past the
                    // 19-digit budget; fall through to per-digit
                    // wrap below so the accumulator stays deterministic.
                    break;
                }
            }
        }
    }
    // Remaining digits (< 8) — SWAR may have stopped mid-run when a
    // partial chunk mixed digits with non-digits; finish byte-by-byte.
    // Wrapping arithmetic matches the SIMD/SWAR folds above: the
    // 19-digit mantissa budget is enforced by `number_parts_to_f64`
    // (which routes n_digits > 18 through `fast_float2`), so the
    // integer accumulator is allowed to wrap at u64 boundaries here.
    while i < len && unsafe { *bytes.get_unchecked(i) }.is_ascii_digit() {
        mantissa = mantissa
            .wrapping_mul(10)
            .wrapping_add((unsafe { *bytes.get_unchecked(i) } - b'0') as u64);
        i += 1;
    }
    let digit_count = i - digit_start;
    let has_pre_dot_digits = digit_count > 0;

    // ── Leading-zero rejection ────────────────────────────────
    if cfg.reject_leading_zero
        && digit_count > 1
        && unsafe { *bytes.get_unchecked(digit_start) } == b'0'
    {
        // `007` etc. — clamp to just the sign + `0`.
        i = digit_start + 1;
        return Some((
            NumberParts {
                mantissa: 0,
                exponent: 0,
                negative: neg,
                n_digits: 1,
                is_integer: true,
            },
            i,
        ));
    }

    // Track total significant digits and decimal exponent for Eisel-Lemire.
    let mut total_digits = digit_count;
    let mut decimal_exponent: i64 = 0;

    // ── Fractional part ───────────────────────────────────────
    let mut has_frac = false;
    // Gate: only enter the dot if we have pre-dot digits OR leading-dot is allowed.
    if i < len
        && unsafe { *bytes.get_unchecked(i) } == b'.'
        && (has_pre_dot_digits || cfg.allow_leading_dot)
    {
        i += 1;
        let frac_start = i;
        // Accumulate fractional digits into mantissa.
        //
        // SIMD 16-digit fast path: scan up to 16 leading digit bytes at
        // once. If all scanned digits fit within the 19-digit mantissa
        // budget, accumulate them in one shot. Otherwise fall through to
        // the chunked/scalar loops that enforce the budget per-digit.
        if total_digits < 19 && i < len {
            if let Some(result) = number_simd::scan_digits_simd(view, i) {
                if total_digits + result.count as usize <= 19 {
                    // All scanned digits fit in the mantissa budget.
                    mantissa = mantissa
                        .wrapping_mul(number_simd::POW10[result.count as usize])
                        .wrapping_add(result.value);
                    i += result.count as usize;
                    total_digits += result.count as usize;
                }
                // If they don't fit, fall through to chunked/scalar loops.
            }
        }
        // 8-digit SWAR chunks for remaining fractional digits.
        while i < len && total_digits + 8 <= 19 {
            let b = unsafe { *bytes.get_unchecked(i) };
            if !b.is_ascii_digit() {
                break;
            }
            let chunk = unsafe { bytes.get_unchecked(i..i + 8) };
            if all_eight_are_ascii_digits(chunk) {
                mantissa = mantissa
                    .wrapping_mul(100_000_000)
                    .wrapping_add(parse_eight_digits(chunk));
                i += 8;
                total_digits += 8;
            } else {
                break;
            }
        }
        while i < len && unsafe { *bytes.get_unchecked(i) }.is_ascii_digit() && total_digits < 19 {
            mantissa = mantissa * 10 + (unsafe { *bytes.get_unchecked(i) } - b'0') as u64;
            i += 1;
            total_digits += 1;
        }
        // Skip remaining fractional digits beyond 19 significant digits.
        while i < len && unsafe { *bytes.get_unchecked(i) }.is_ascii_digit() {
            i += 1;
        }
        let frac_digits = i - frac_start;
        if frac_digits == 0 {
            // '.' with no digits after — backtrack the dot.
            i -= 1;
        } else {
            has_frac = true;
            // Fractional digits shift the exponent negative.
            decimal_exponent -= (i - frac_start) as i64;
            // But we only accumulated min(frac_digits, 19-digit_count) of them.
            let accumulated_frac = total_digits - digit_count;
            decimal_exponent += (frac_digits - accumulated_frac) as i64;
        }
    }

    // Must have at least some digits (before or after dot).
    if !has_pre_dot_digits && !has_frac {
        return None;
    }

    // ── Exponent (e/E) ────────────────────────────────────────
    let mut has_exp = false;
    if i < len {
        let b = unsafe { *bytes.get_unchecked(i) };
        if b == b'e' || b == b'E' {
            has_exp = true;
            let exp_mark = i;
            i += 1;
            let mut exp_neg = false;
            if i < len {
                let b = unsafe { *bytes.get_unchecked(i) };
                if b == b'+' {
                    i += 1;
                } else if b == b'-' {
                    exp_neg = true;
                    i += 1;
                }
            }
            let exp_digit_start = i;
            let mut explicit_exp: i64 = 0;
            while i < len && unsafe { *bytes.get_unchecked(i) }.is_ascii_digit() {
                explicit_exp =
                    explicit_exp * 10 + (unsafe { *bytes.get_unchecked(i) } - b'0') as i64;
                i += 1;
                if explicit_exp > 999 {
                    // Clamp to avoid overflow; Eisel-Lemire handles out-of-range.
                    explicit_exp = 999;
                }
            }
            if i == exp_digit_start {
                has_exp = false;
                i = exp_mark; // backtrack
            } else {
                decimal_exponent += if exp_neg { -explicit_exp } else { explicit_exp };
            }
        }
    }

    if i == start {
        return None;
    }

    let is_integer = !has_frac && !has_exp;

    Some((
        NumberParts {
            mantissa,
            exponent: decimal_exponent as i32,
            negative: neg,
            n_digits: total_digits as u32,
            is_integer,
        },
        i,
    ))
}
